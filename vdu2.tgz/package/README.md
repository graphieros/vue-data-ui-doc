<p align="center">
    <a href="https://vue-data-ui.graphieros.com/"><img width="500" src="https://github.com/user-attachments/assets/19d4334d-679c-4c19-bc4f-6050810afa05"></a>
    <br>
    <a href="https://vue-data-ui.graphieros.com/"><img width="100%" src="https://github.com/user-attachments/assets/0474eb0e-0918-43e1-9756-30a5a8052d82"></a>

</p>

# vue-data-ui

[![Version](https://npmx.dev/api/registry/badge/version/vue-data-ui)](https://npmx.dev/vue-data-ui)
[![License](https://npmx.dev/api/registry/badge/license/vue-data-ui)](https://npmx.dev/package/vue-data-ui)
[![Types](https://npmx.dev/api/registry/badge/types/vue-data-ui)](https://npmx.dev/package/vue-data-ui)
[![npm downloads](https://npmx.dev/api/registry/badge/downloads/vue-data-ui)](https://npmx.dev/package/vue-data-ui?modal=chart)
[![Static Badge](https://npmx.dev/api/registry/badge/version/nuxt?color=22c55e&value=70&label=components)](https://vue-data-ui.graphieros.com)
[![GitHub issues](https://img.shields.io/github/issues/graphieros/vue-data-ui)](https://github.com/graphieros/vue-data-ui/issues)
[![MadeWithVueJs.com shield](https://madewithvuejs.com/storage/repo-shields/4526-shield.svg)](https://madewithvuejs.com/p/vue-data-ui/shield-link)
[![GitHub Repo stars](https://img.shields.io/github/stars/graphieros/vue-data-ui)](https://github.com/graphieros/vue-data-ui)

A user-empowering data visualization Vue component library for eloquent data storytelling.

Interactive Documentation:

- Deployed Site - [Vue Data UI](https://vue-data-ui.graphieros.com/)
- GitHub Repo - [vue-data-ui-doc](https://github.com/graphieros/vue-data-ui-doc)

Available components

## Charts

- [VueUiAgePyramid](https://vue-data-ui.graphieros.com/docs#vue-ui-age-pyramid)
- [VueUiBump](https://vue-data-ui.graphieros.com/docs#vue-ui-bump)
- [VueUiCandlestick](https://vue-data-ui.graphieros.com/docs#vue-ui-candlestick)
- [VueUiChestnut](https://vue-data-ui.graphieros.com/docs#vue-ui-chestnut)
- [VueUiChord](https://vue-data-ui.graphieros.com/docs#vue-ui-chord)
- [VueUiCirclePack](https://vue-data-ui.graphieros.com/docs#vue-ui-circle-pack)
- [VueUiDag](https://vue-data-ui.graphieros.com/docs#vue-ui-dag)
- [VueUiDonutEvolution](https://vue-data-ui.graphieros.com/docs#vue-ui-donut-evolution)
- [VueUiDonut](https://vue-data-ui.graphieros.com/docs#vue-ui-donut)
- [VueUiDumbbell](https://vue-data-ui.graphieros.com/docs#vue-ui-dumbbell)
- [VueUiFlow](https://vue-data-ui.graphieros.com/docs#vue-ui-flow)
- [VueUiFunnel](https://vue-data-ui.graphieros.com/docs#vue-ui-funnel)
- [VueUiGalaxy](https://vue-data-ui.graphieros.com/docs#vue-ui-galaxy)
- [VueUiGauge](https://vue-data-ui.graphieros.com/docs#vue-ui-gauge)
- [VueUiGraph](https://vue-data-ui.graphieros.com/docs#vue-ui-graph)
- [VueUiHeatmap](https://vue-data-ui.graphieros.com/docs#vue-ui-heatmap)
- [VueUiHistoryPlot](https://vue-data-ui.graphieros.com/docs#vue-ui-history-plot)
- [VueUiHorizontalBar](https://vue-data-ui.graphieros.com/docs#vue-ui-horizontal-bar)
- [VueUiMolecule](https://vue-data-ui.graphieros.com/docs#vue-ui-molecule)
- [VueUiMoodRadar](https://vue-data-ui.graphieros.com/docs#vue-ui-mood-radar)
- [VueUiNestedDonuts](https://vue-data-ui.graphieros.com/docs#vue-ui-nested-donuts)
- [VueUiOnion](https://vue-data-ui.graphieros.com/docs#vue-ui-onion)
- [VueUiParallelCoordinatePlot](https://vue-data-ui.graphieros.com/docs#vue-ui-parallel-coordinate-plot)
- [VueUiQuadrant](https://vue-data-ui.graphieros.com/docs#vue-ui-quadrant)
- [VueUiQuickChart](https://vue-data-ui.graphieros.com/docs#vue-ui-quick-chart)
- [VueUiRadar](https://vue-data-ui.graphieros.com/docs#vue-ui-radar)
- [VueUiRelationCircle](https://vue-data-ui.graphieros.com/docs#vue-ui-relation-circle)
- [VueUiRidgeline](https://vue-data-ui.graphieros.com/docs#vue-ui-ridgeline)
- [VueUiRings](https://vue-data-ui.graphieros.com/docs#vue-ui-rings)
- [VueUiScatter](https://vue-data-ui.graphieros.com/docs#vue-ui-scatter)
- [VueUiStackbar](https://vue-data-ui.graphieros.com/docs#vue-ui-stackbar)
- [VueUiStackline](https://vue-data-ui.graphieros.com/docs#vue-ui-stackline)
- [VueUiStripPlot](https://vue-data-ui.graphieros.com/docs#vue-ui-strip-plot)
- [VueUiThermometer](https://vue-data-ui.graphieros.com/docs#vue-ui-thermometer)
- [VueUiTiremarks](https://vue-data-ui.graphieros.com/docs#vue-ui-tiremarks)
- [VueUiTreemap](https://vue-data-ui.graphieros.com/docs#vue-ui-treemap)
- [VueUiWaffle](https://vue-data-ui.graphieros.com/docs#vue-ui-waffle)
- [VueUiWheel](https://vue-data-ui.graphieros.com/docs#vue-ui-wheel)
- [VueUiWordCloud](https://vue-data-ui.graphieros.com/docs#vue-ui-word-cloud)
- [VueUiXyCanvas](https://vue-data-ui.graphieros.com/docs#vue-ui-xy-canvas)
- [VueUiXy](https://vue-data-ui.graphieros.com/docs#vue-ui-xy)

## Mini charts

- [VueUiSparkHistogram](https://vue-data-ui.graphieros.com/docs#vue-ui-sparkhistogram)
- [VueUiSparkbar](https://vue-data-ui.graphieros.com/docs#vue-ui-sparkbar)
- [VueUiSparkgauge](https://vue-data-ui.graphieros.com/docs#vue-ui-sparkgauge)
- [VueUiSparkline](https://vue-data-ui.graphieros.com/docs#vue-ui-sparkline)
- [VueUiSparkStackbar](https://vue-data-ui.graphieros.com/docs#vue-ui-sparkstackbar)
- [VueUiSparkTrend](https://vue-data-ui.graphieros.com/docs#vue-ui-spark-trend)
- [VueUiGizmo](https://vue-data-ui.graphieros.com/docs#vue-ui-gizmo)
- [VueUiBullet](https://vue-data-ui.graphieros.com/docs#vue-ui-bullet)

## 3d

- [VueUi3dBar](https://vue-data-ui.graphieros.com/docs#vue-ui-3d-bar)

## Tables

- [VueUiTableHeatmap](https://vue-data-ui.graphieros.com/docs#vue-ui-table-heatmap)
- [VueUiTableSparkline](https://vue-data-ui.graphieros.com/docs#vue-ui-table-sparkline)
- [VueUiTable](https://vue-data-ui.graphieros.com/docs#vue-ui-table)
- [VueUiCarouselTable](https://vue-data-ui.graphieros.com/docs#vue-ui-carousel-table)

## Rating

- [VueUiRating](https://vue-data-ui.graphieros.com/docs#vue-ui-rating)
- [VueUiSmiley](https://vue-data-ui.graphieros.com/docs#vue-ui-smiley)

## Maps

- [VueUiGeo](https://vue-data-ui.graphieros.com/docs#vue-ui-geo)
- [VueUiWorld](https://vue-data-ui.graphieros.com/docs#vue-ui-world)

## Productivity

- [VueUiHill](https://vue-data-ui.graphieros.com/docs#vue-ui-hill)

## Utilities

- [VueUiAccordion](https://vue-data-ui.graphieros.com/docs#vue-ui-accordion)
- [VueUiAnnotator](https://vue-data-ui.graphieros.com/docs#vue-ui-annotator)
- [VueUiCursor](https://vue-data-ui.graphieros.com/docs#vue-ui-cursor)
- [VueUiDashboard](https://vue-data-ui.graphieros.com/docs#vue-ui-dashboard)
- [VueUiDigits](https://vue-data-ui.graphieros.com/docs#vue-ui-digits)
- [VueUiIcon](https://vue-data-ui.graphieros.com/docs#vue-ui-icon)
- [VueUiKpi](https://vue-data-ui.graphieros.com/docs#vue-ui-kpi)
- [VueUiMiniLoader](https://vue-data-ui.graphieros.com/docs#vue-ui-mini-loader)
- [VueUiSkeleton](https://vue-data-ui.graphieros.com/docs#vue-ui-skeleton)
- [VueUiTimer](https://vue-data-ui.graphieros.com/docs#vue-ui-timer)

# Installation

```
pnpm add vue-data-ui
```

You can declare components globally in your main.js:

```js
import { createApp } from 'vue';
import App from './App.vue';
// Include the css;
import 'vue-data-ui/style.css';

// You can declare Vue Data UI components globally
import { VueUiRadar } from 'vue-data-ui';

const app = createApp(App);

app.component('VueUiRadar', VueUiRadar);
app.mount('#app');
```

Or you can import just what you need into your files:

```js
<script setup>import {(VueUiRadar, VueUiXy)} from "vue-data-ui";</script>
```

You can also use the "VueDataUi" universal component, just specifying which component you are using. You can of course use the slots provided, if the target component has them.

```js
<script setup>
import { ref } from "vue";
import { VueDataUi } from "vue-data-ui";
// Include the css;
import "vue-data-ui/style.css";

const config = ref({...});
const dataset = ref([...]);

</script>

<template>

  <VueDataUi
    component="VueUiXy"
    :config="config"
    :dataset="dataset"
  />

</template>

```

Note that the following utility components are not supported by the universal VueDataUi component and must be imported individually:

- Arrow
- VueUiIcon
- VueUiPattern

## Typescript

Types are available in the 'vue-data-ui.d.ts' file under the types directory of the package.

## Vue Data UI version2 -> version3 migration

Vue Data UI v3 does not contain breaking changes.
However, some charts have their padding configs modified, which can lead to excessive padding with a v2 config.

### Version 3 features

- `config.loading` (default: false) toggle loading state manually, to display a beautiful skeleton loader which uses the same chart component and shares layout features derived from your config. This skeleton loader is also triggered automatically if the provided dataset is undefined.

- `config.debug` (default: false) set to true to show warning messages during development, turn off for production.

- smart label resizing and auto-rotating features

- more charts support responsive mode

- config event callbacks

## Nuxt

[This repo contains a boilerplate implementation of the vue-data-ui package in Nuxt](https://github.com/graphieros/vue-data-ui-nuxt)

# Customizable tooltips

Charts with tooltips have a config option to customize tooltip contents:

```js

customFormat: ({ seriesIndex, datapoint, series, config }) => {
  return `<div>${ ... }</div>`;
}

```

# Data formatting

Data labels can be customized using the `formatter` config attribute (since v2.3.29 on all chart components):

```
// the formatter attribute is generally placed under the label or dataLabel config attribute objects

const config = ref({
  formatter: ({ value, config }) => {
    return `formatted ${value}`;
  }
})

```

# Slots

## #svg slot

Most Vue Data UI chart components include a `#svg` slot you can use to introduce custom SVG elements (shapes, text, etc.) above the chart content.

```html
<VueUiXy :dataset="dataset" :config="config">
    <template #svg="{ svg }">
        <foreignObject x="100" y="0" height="100" width="150">
            <div>This is a custom caption</div>
        </foreignObject>
    </template>
</VueUiXy>
```

The `#svg` slot also works when using the `VueDataUi` universal component, if the component it wraps supports it.

## #svg-underlayer slot

Every component with a `#svg` slot also exposes `#svg-underlayer` for custom SVG content beneath the chart. Use it for background shapes, highlighted regions, or other decorations that should appear behind the data.

The underlayer exposes exactly the same slot props and uses the same coordinates as the component's `#svg` slot. Props vary by component; for example, `VueUiXy` exposes dimensions, `drawingArea`, `data`, `slicer`, and export flags inside `svg`. Both slots use the same TypeScript slot props type, such as `VueUiXySvgSlotProps`.

```html
<VueUiXy :dataset="dataset" :config="config">
    <template #svg-underlayer="{ svg }">
        <rect
            :x="svg.drawingArea.left"
            :y="svg.drawingArea.top"
            :width="svg.drawingArea.width / 2"
            :height="svg.drawingArea.height"
            fill="chocolate"
            opacity="0.15"
            pointer-events="none"
        />
    </template>
</VueUiXy>
```

Underlayer content renders beneath the chart content, including the `#chart-background` slot. Opaque chart backgrounds can cover it.

The `#svg-underlayer` slot also works through the `VueDataUi` universal component when the wrapped component supports `#svg`.

## #legend slot (since v.2.0.41)

All charts expose a #legend slot except for:

- VueUiCirclePack
- VueUiDumbbell
- VueUiFlow
- VueUiFunnel
- VueUiHeatmap
- VueUiHill
- VueUiRelationCircle
- VueUiSparkHistogram
- VueUiSparkStackbar
- VueUiSparkbar
- VueUiSparkgauge
- VueUiSparkline
- VueUiThermometer
- VueUiTimer
- VueUiTiremarks
- VueUiWheel

The legend slot also works when using the VueDataUi universal component, if the component it wraps supports it.
It is recommended to set the show legend config attribute to false, to hide the default legend.

```html
<VueUiDonut :config="config" :dataset="dataset">
    <template #legend="{ legend }">
        <div v-for="item in legend">{{ legend.name }}</div>
    </template>
</VueUiDonut>
```

## Legend toggle

An opt-in config option displays a toggle button to hide/show all series, when the number of series > 2.
This attribute can be found in the `legend.selectAllToggle` config section:

```js
legend: {
  selectAllToggle: {
    show: false,
    backgroundColor: '#E1E5E8',
    color: '#2D353C'
  }
}
```

This legend toggle option is available for the following components:

- VueUiDonut
- VueUiDonutEvolution
- VueUiGalaxy
- VueUiHistoryPlot
- VueUiHorizontalBar
- VueUiNestedDonuts
- VueUiOnion
- VueUiParallelCoordinatePlot
- VueUiQuadrant
- VueUiQuickChart
- VueUiRadar
- VueUiRidgeline
- VueUiRings
- VueUiRings
- VueUiScatter
- VueUiSparkStackbar
- VueUiStackbar
- VueUiStackline
- VueUiTreemap
- VueUiWaffle
- VueUiWorld
- VueUiXy
- VueUiXyCanvas

## Tooltip slots

Use the #tooltip slot to customize tooltip contents.
You will usually only need the `datapoint` attribute exposed by the slot, but you can always log what the slot provides if you need more.

```html
<VueUiXy :dataset :config>
    <template #tooltip="{ ...tooltip }">
        <div>
            <span>{{ tooltip.timeLabel.text }}</span>
            <div v-for="serie in tooltip.datapoint" :key="serie.id">
                {{ serie.name }}: {{ serie.value }}
            </div>
        </div>
    </template>
</VueUiXy>
```

Customize tooltip contents with #tooltip-before and #tooltip-after slots, to include an image, another chart or any other rich content into your tooltips.
It's an alternative to the config option `tooltip.customFormat`, in case richer tooltip content is needed.

All slots expose the following object:

```
{
  datapoint,
  seriesIndex,
  series,
  config,
}
```

Components with time series will also expose an additional `timeLabel` attribute.

The following charts bear these slots:

- VueUiAgePyramid
- VueUiCandlestick
- VueUiCirclePack
- VueUiDonut
- VueUiGalaxy
- VueUiGraph
- VueUiHeatmap
- VueUiHistoryPlot
- VueUiHorizontalBar
- VueUiMolecule
- VueUiNestedDonuts
- VueUiOnion
- VueUiParallelCoordinatePlot
- VueUiQuadrant
- VueUiQuickChart
- VueUiRadar
- VueUiRings
- VueUiScatter
- VueUiSparkStackbar
- VueUiStackbar
- VueUiStackline
- VueUiTreemap
- VueUiWordCloud
- VueUiWorld
- VueUiXy \*
- VueUiXyCanvas
- VueUiwaffle

\* VueUiXy slots specifically expose the following additional attributes:

```

{
  ...,
  bars,
  lines,
  plots
}

```

```html
<VueUiDonut :config="config" :dataset="dataset">
  <template #tooltip-before={ datapoint, seriesIndex, dataset, config }">
    <div>
      This content shows first
    </div>
  </template>
  <template #tooltip-after={ datapoint, seriesIndex, dataset, config }">
    <div>
      This content shows the last
    </div>
  </template>
</VueUiDonut>
```

The #tooltip-before & #tooltip-after slots also work when using the VueDataUi universal component, if the component it wraps supports them.

## Add a watermark using the #watermark slot

You can use the #watermark slot to include any watermark content with your own styling.
This slot exposes the isPrinting boolean you can use to display the watermark only when producing a pdf or an image.

```html
<VueUiDonut :config="config" :dataset="dataset">
    <template #watermark="{ isPrinting }">
        <div
            v-if="isPrinting"
            style="font-size: 100px; opacity: 0.1; transform: rotate(-10deg)"
        >
            WATERMARK
        </div>
    </template>
</VueUiDonut>
```

## Customization of the zoom reset button with the #reset-action slot

Available for the following components:

- VueUiQuickChart (for line & bar types only)
- VueUiXy
- VueUiDonutEvolution
- VueUiCandlestick
- VueUiWordCloud

The config option zoom.useResetSlot must be set to true to use the slot.

```html
<VueUiXy :config="config" :dataset="dataset">
    <template #reset-action="{ reset }">
        <button @click="reset()">RESET ZOOM</button>
    </template>
</VueUiXy>
```

# Config

If for some reason you can't access the documentation website and need to get the default config object for a component:

```js
import { getVueDataUiConfig } from 'vue-data-ui';

const defaultConfigXy = getVueDataUiConfig('vue_ui_xy');
```

# Themes (since v2.2.9)

All charts are set by default without a theme, and use the default color palette.

9 themes are available for all charts:

- default (or '')
- dark
- zen
- hack
- concrete
- celebration
- celebrationNight
- minimal
- minimalDark

Any color provided in dataset props will override the colors used by the theme for datapoints.

To use a theme, set the theme attribute of the config prop, for example:

```js
const donutConfig = ref({
  theme: 'zen',
  ...
})
```

# Quick custom theme

You can quickly setup your own theme for a given chart:

```js
import { getVueDataUiConfig, mergeConfigs } from 'vue-data-ui';

// Get the default config and set color options
const customTheme = getVueDataUiConfig('vue_ui_xy', {
    colorBackground: '#1A1A1A',
    colorTextPrimary: '#CD9077',
    colorTextSecondary: '#825848',
    colorGrid: '#CD9077',
    colorBorder: '#CD9077',
});

const config = computed(() => {
    // Use the `mergeConfigs` utility to set additional configurations while preserving your theme
    return mergeConfigs({
        defaultConfig: customTheme,
        userConfig: {
            chart: {
                title: {
                    text: 'Title',
                    subtitle: {
                        text: 'Subtitle',
                    },
                },
            },
        },
    });
});
```

# Available components : details

Type definitions are available in the `vue-data-ui.d.ts` file in the `dist/types` directory.

### Universal component

<!-- prettier-ignore -->
| Name | dataset type | config type | emits / exposed methods | slots | custom tooltip | themes |
| --- | --- | --- | --- | --- | --- | --- |
| `VueDataUi` | (depends on component) | (depends on component) | (depends on component) | (depends on component) | (depends on component) | (depends on component) |

### Quick chart

From the dataset you pass into the props, this component will produce the most adapted chart (either a line, bar or donut chart)

<!-- prettier-ignore -->
| Name | dataset type | config type | emits / exposed methods | slots | custom tooltip | themes |
| --- | --- | --- | --- | --- | --- | --- |
| `VueUiQuickChart` | `VueUiQuickChartDataset` | `VueUiQuickChartConfig` | `@zoomStart`, `@zoomEnd`, `@zoomReset`, `@copyAlt`, `@selectDatapoint`, `@selectLegend`, `generatePdf`, `generateImage`, `toggleTooltip` | `#legend`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#reset-action`, `#watermark`, `#chart-background` | ✅ | ✅ |

### Mini charts

<!-- prettier-ignore -->
| Name | dataset type | config type | emits / exposed methods | slots | custom tooltip | themes |
| --- | --- | --- | --- | --- | --- | --- |
| `VueUiSparkline` | `VueUiSparklineDatasetItem[]` | `VueUiSparklineConfig` | `@selectDatapoint`, `@hoverIndex`, `@zoom`, `@zoomReset` | `#svg`, `#svg-underlayer`, `#before`, `#chart-background`, `#tooltip`, `#hint` | ✅ | ✅ |
| `VueUiSparkbar` | `VueUiSparkbarDatasetItem[]` | `VueUiSparkbarConfig` | `@selectDatapoint` | `#data-label`, `#title` | ❌ | ✅ |
| `VueUiSparkStackbar` | `VueUiSparkStackbarDatasetItem[]` | `VueUiSparkStackbarConfig` | `@selectDatapoint`, `@selectLegend` | `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#hint` | ✅ | ✅ |
| `VueUiSparkHistogram` | `VueUiSparkHistogramDatasetItem[]` | `VueUiSparkHistogramConfig` | `@selectDatapoint` | `#chart-background`, `#hint` | ❌ | ✅ |
| `VueUiSparkGauge` | `VueUiSparkGaugeDataset` | `VueUiSparkGaugeConfig` | ❌ | `#chart-background` | ❌ | ✅ |
| `VueUiSparkTrend` | `number[]` | `VueUiSparkTrendConfig` | ❌ | `#chart-background` | ❌ | ✅ |
| `VueUiGizmo` | `VueUiGizmoDataset` | `VueUiGizmoConfig` | ❌ | ❌ | ❌ | ❌ |
| `VueUiBullet` | `VueUiBulletDataset` | `VueUiBulletConfig` | `generatePdf`, `generateImg`, `getData`, `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#watermark`, `#chart-background` | ❌ | ✅ |

### Charts

<!-- prettier-ignore -->
| Name | dataset type | config type | emits / exposed methods | slots | custom tooltip | themes |
| --- | --- | --- | --- | --- | --- | --- |
| `VueUiAgePyramid` | `Array<Array<string / number>>` | `VueUiSparklineConfig` | `generatePdf`, `generateImage`, `generateCsv`, `toggleTable`, `toggleTooltip`, `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#watermark`, `#chart-background`, `#hint` | ✅ | ✅ |
| `VueUiBump` | `VueUiBumpDatapointItem[]` | `VueUiBumpConfig` | `generatePdf`, `generateImage`, `generateCsv`, `toggleTable`, `getData`, `getImage` | `#svg`, `#svg-underlayer`, `#watermark`, `#chart-background`, `#time-label`, `#hint` | ❌ | ✅ |
| `VueUiCandlestick` | `Array<Array<string / number>>` | `VueUiCandlestickConfig` | `@selectX`, `@zoomStart`, `@zoomEnd`, `@zoomReset`, `@copyAlt`, `generatePdf`, `generateImage`, `generateCsv`, `toggleTable`, `toggleTooltip`, `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#reset-action`, `#watermark`, `#chart-background`, `#hint` | ✅ | ✅ |
| `VueUiChestnut` | `VueUiChestnutDatasetRoot[]` | `VueUiChestnutConfig` | `@selectRoot`, `@selectBranch`, `@selectNut`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#watermark`, `#chart-background`, `#hint`, `#hint` | ❌ | ✅ |
| `VueUiChord` | `VueUiChordDataset` | `VueUiChordConfig` | `@selectLegend`, `@selectGroup`, `@selectRibbon`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#watermark`, `#chart-background`, `#pattern`, `#hint` | ❌ | ✅ |
| `VueUiCirclePack` | `VueUiCirclePackDatasetItem[]` | `VueUiCirclePackConfig` | `@selectDatapoint`, `getData`, `generatePdf`, `generateImage`, `generateCsv`, `toggleTable`, `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#watermark`, `#chart-background` , `#pattern`, `#zoom-label`, `#data-label`, `#tooltip-before`, `#tooltip-after`, `#hint` | ✅ | ✅ |
| `VueUiDag` | `VueUiDagDataset` | `VueUiDagConfig` | `@onNodeClick`, `@onMidpointEnter`, `@onMidpointLeave`, `focusOnNode`, `getData`, `getImage`, `generatePdf`, `generateImage`, `generateSvg`, `toggleAnnotator`, `toggleFullscreen`, `zoomIn`, `zoomOut`, `resetZoom`, `switchDirection` | `#svg`, `#svg-underlayer`, `#source`, `#node-label`, `#node`, `#tooltip-midpoint`, `#tooltip-node`, `#background-pattern`, `#hint` | ❌ | ✅ |
| `VueUiDonutEvolution` | `VueUiDonutEvolutionDatasetItem[]` | `VueUiDonutEvolutionConfig` | `@zoomStart`, `@zoomEnd`, `@zoomReset`, `@copyAlt`, `@selectLegend`, `hideSeries`, `showSeries`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable` , `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#reset-action`, `#watermark`, `#chart-background`, `#hint` | ❌ | ✅ |
| `VueUiDonut` | `VueUiDonutDatasetItem[]` | `VueUiDonutConfig` | `@selectDatapoint`, `@selectLegend`, `hideSeries`, `showSeries`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `toggleLabels`, `toggleTooltip`, `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#dataLabel`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#plot-comment`, `#watermark`, `#chart-background`, `#pattern`, `#hint` | ✅ | ✅ |
| `VueUiDumbbell` | `VueUiDumbbellDataset[]` | `VueUiDumbbellConfig` | `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#watermark`, `#chart-background`, `#hint` | ❌ | ✅ |
| `VueUiFlow` | `VueUiFlowDatasetItem[]` | `VueUiFlowConfig` | `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `toggleTooltip`, `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#watermark`, `#chart-background`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#hint` | ✅ | ✅ |
| `VueUiFunnel` | `VueUiFunnelDatasetItem[]` | `VueUiFunnelConfig` | `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `getImage` | `#svg`, `#svg-underlayer`, `#watermark`, `#chart-background`, `#hint` | ❌ | ✅ |
| `VueUiGalaxy` | `VueUiGalaxyDatasetItem[]` | `VueUiGalaxyConfig` | `@selectDatapoint`, `@selectLegend`, `hideSeries`, `showSeries`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `toggleTooltip` , `getImage` | `#svg`, `#svg-underlayer`, `#legend`,`#tooltip`, `#tooltip-before`, `#tooltip-after`, `#chart-background`, `#hint` | ✅ | ✅ |
| `VueUiGauge` | `VueUiGaugeDataset` | `VueUiGaugeConfig` | `generatePdf`, `generateImage`, `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#watermark`, `#chart-background`, `#pattern` | ❌ | ✅ |
| `VueUiGraph` | `VueUiGraphDataset` | `VueUiGraphConfig` | `@selectNode`, `@hoverNode`, `@zoom`, `@zoomReset`, `@layoutStart`, `@layoutEnd`, `@copyAlt`, `zoomIn`, `zoomOut`, `resetZoom`, `fitToView`, `focusNode`, `resetLayout`, `getData`, `getImage`, `generatePdf`, `generateImage`, `generateSvg`, `generateCsv`, `toggleTable`, `toggleTooltip`, `toggleFullscreen`, `toggleZoom`, `toggleAnnotator`, `copyAlt` | `#node`, `#svg`, `#svg-underlayer`, `#chart-background`, `#watermark`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#hint`, `#source`, `#skeleton` | ✅ | ✅ |
| `VueUiHeatmap` | `VueUiHeatmapDatasetItem[]` | `VueUiHeatmapConfig` | `@selectDatapoint`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `toggleTooltip`, `getImage` | `#svg`, `#svg-underlayer`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#watermark`, `#chart-background`, `#hint` | ✅ | ✅ |
| `VueUiHistoryPlot` | `VueUiHistoryPlotDatasetItem[]` | `VueUiHistoryPlotConfig` | `@selectDatapoint`, `@selectLegend`, `hideSeries`, `showSeries`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `toggleTooltip`, `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#watermark`, `#chart-background`, `#hint` | ✅ | ✅ |
| `VueUiHorizontalBar` | `VueUiHorizontalBarDatasetItem[]` | `VueUiWheelConfig` | `@selectDatapoint`, `@selectLegend`, `hideSeries`, `showSeries`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `toggleSort`, `toggleTooltip` , `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#watermark`, `#chart-background`, `#pattern`, `#hint` | ✅ | ✅ |
| `VueUiMolecule` | `VueUiMoleculeDatasetNode[]` | `VueUiMoleculeConfig` | `@selectNode`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `toggleLabels`, `toggleTooltip`, `getImage` | `#node`, `#svg`, `#svg-underlayer`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#watermark`, `#chart-background` | ✅ | ✅ |
| `VueUiMoodRadar` | `VueUiMoodRadarDataset` | `VueUiMoodRadarConfig` | `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable` , `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#watermark`, `#chart-background`, `#hint` | ❌ | ✅ |
| `VueUiNestedDonuts` | `VueUiNestedDonutsDatasetItem[]` | `VueUiNestedDonutsConfig` | `@selectDatapoint`, `@selectLegend`, `hideSeries`, `showSeries`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `toggleLabels`, `toggleTooltip` , `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#watermark`, `#chart-background`, `#hint` | ✅ | ✅ |
| `VueUiOnion` | `VueUiOnionDatasetItem[]` | `VueUiOnionConfig` | `@selectLegend`, `hideSeries`, `showSeries`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `toggleTooltip`, `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#watermark`, `#chart-background`, `#hint` | ✅ | ✅ |
| `VueUiParallelCoordinatePlot` | `VueUiParallelCoordinatePlotDatasetItem[]` | `VueUiParallelCoordinatePlotConfig` | `@selectLegend`, `@selectDatapoint`, `hideSeries`, `showSeries`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `toggleLabels`, `toggleTooltip`, `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#plot-comment`, `#watermark`, `#chart-background`, `#hint` | ✅ | ✅ |
| `VueUiQuadrant` | `VueUiQuadrantDatasetItem[]` | `VueUiQuadrantConfig` | `@selectLegend`, `@selectPlot`, `@selectSide`, `hideSeries`, `showSeries`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `toggleLabels`, `toggleTooltip`, `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#watermark`, `#chart-background`, `#datapoint`, `#hint` | ✅ | ✅ |
| `VueUiRadar` | `VueUiRadarDataset` | `VueUiRadarConfig` | `@selectLegend`, `hideSeries`, `showSeries`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `toggleTooltip` , `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#watermark`, `#chart-background`, `#hint` | ✅ | ✅ |
| `VueUiRidgeline` | `VueUiRidgelineDatasetItem[]` | `VueUiRidgelineConfig` | `@selectLegend`, `@selectX`, `@selectDatapoint`, `hideSeries`, `showSeries`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable` , `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#time-label`,`#watermark`, `#chart-background`, `#pattern`, `#hint` | ❌ | ✅ |
| `VueUiRings` | `VueUiRingsDatasetItem[]` | `VueUiRingsConfig` | `@selectLegend`, `hideSeries`, `showSeries`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `toggleTooltip` , `toggleLabels`, `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#watermark`, `#chart-background`, `#pattern`, `#hint` | ✅ | ✅ |
| `VueUiScatter` | `VueUiScatterDatasetItem[]` | `VueUiScatterConfig` | `hideSeries`, `showSeries`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `toggleTooltip` , `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#watermark`, `#chart-background`, `#hint` | ✅ | ✅ |
| `VueUiStackbar` | `VueUiStackbarDatasetItem[]` | `VueUiStackbarConfig` | `@selectX`, `@zoomStart`, `@zoomEnd`, `@zoomReset`, `@copyAlt`, `@selectLegend`, `@selectDatapoint`, `@selectTimeLabel`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `toggleLabels`, `toggleTooltip` , `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#time-label`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#reset-action`, `#watermark`, `#chart-background`, `#pattern`, `#hint` | ✅ | ✅ |
| `VueUiStackline` | `VueUiStacklineDatasetItem[]` | `VueUiStacklineConfig` | `@selectX`, `@zoomStart`, `@zoomEnd`, `@zoomReset`, `@copyAlt`, `@selectLegend`, `@selectDatapoint`, `@selectTimeLabel`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `toggleLabels`, `toggleTooltip` , `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#time-label`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#reset-action`, `#watermark`, `#chart-background`, `#pattern`, `#hint` | ✅ | ✅ |
| `VueUiStripPlot` | `VueUiStripPlotDataset[]` | `VueUiStripPlotConfig` | `@selectDatapoint`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `toggleLabels`, `toggleTooltip` , `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#watermark`, `#chart-background`, `#hint` | ✅ | ✅ |
| `VueUiThermometer` | `VueUiThermometerDataset` | `VueUiThermometerConfig` | `generatePdf`, `generateImage` , `getImage` | `#svg`, `#svg-underlayer`, `#watermark`, `#chart-background` | ❌ | ✅ |
| `VueUiTiremarks` | `VueUiTiremarksDataset` | `VueUiTiremarksConfig` | `generatePdf`, `generateImage` , `getImage` | `#svg`, `#svg-underlayer`, `#legend`, `#watermark`, `#chart-background` | ❌ | ✅ |
| `VueUiTreemap` | `VueUiTreemapDatasetItem[]` | `VueUiTreemapConfig` | `@selectLegend`, `@selectDatapoint`, `hideSeries`, `showSeries`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `toggleTooltip` , `getImage`, `#hint` | `#svg`, `#svg-underlayer`, `#rect`, `#legend`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#watermark`, `#breadcrumb-label`, `#breadcrumb-arrow`, `#group-label` | ✅ | ✅ |
| `VueUiWaffle` | `VueUiWaffleDatasetItem[]` | `VueUiWaffleConfig` | `@selectLegend`, `hideSeries`, `showSeries`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `toggleTooltip` , `getImage`, `#hint` | `#svg`, `#svg-underlayer`, `#legend`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#watermark`, `#pattern` | ✅ | ✅ |
| `VueUiWheel` | `VueUiWheelDataset` | `VueUiWheelConfig` | `generatePdf`, `generateImage` , `getImage` | `#svg`, `#svg-underlayer`, `#watermark`, `#chart-background` | ❌ | ✅ |
| `VueUiWordCloud` | `VueUiWordCloudDatasetItem[] / string` | `VueUiWordCloudConfig` | `getData`, `generatePdf`, `generateImage`, `generateCsv`, `toggleTooltip` , `getImage`, `#hint` | `#svg`, `#svg-underlayer`, `#reset-action`, `#watermark`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#chart-background` | ✅ | ✅ |
| `VueUiXyCanvas` | `VueUiXyCanvasDatasetItem[]` | `VueUiXyCanvasConfig` | `@selectX`, `@zoomStart`, `@zoomEnd`, `@zoomReset`, `@copyAlt`, `@selectLegend`, `hideSeries`, `showSeries`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `toggleLabels`, `toggleStack`, `toggleTooltip` , `getImage`, `#hint` | `#legend`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#reset-action`, `#watermark` | ✅ | ✅ |
| `VueUiXy` | `VueUiXyDatasetItem[]` | `VueUiXyConfig` | `@selectLegend`, `@selectX`, `@selectTimeLabel`, `hideSeries`, `showSeries`, `getData`, `generatePdf`, `generateCsv`, `generateImage`, `toggleTable`, `toggleLabels`, `toggleStack`, `toggleTooltip` , `getImage`, `#hint` | `#svg`, `#svg-underlayer`, `#legend`, `#time-label`, `#tooltip`, `#tooltip-before`, `#tooltip-after`, `#reset-action`, `#plot-comment`,`#watermark`, `#chart-background`, `#pattern`, `#area-gradient`, `#bar-gradient` | ✅ | ✅ |

### 3D charts

<!-- prettier-ignore -->
| Name | dataset type | config type | emits / exposed methods | slots | custom tooltip | themes |
| --- | --- | --- | --- | --- | --- | --- |
| `VueUi3dBar` | `VueUi3dBarDataset` | `VueUi3dBarConfig` | `generatePdf`, `generateImage`, `toggleTable`, `getImage` | `#svg`, `#svg-underlayer`, `#watermark`, `#chart-background`, `#hint` | ❌ | ✅ |

### Maps

<!-- prettier-ignore -->
| Name | dataset type | config type | emits / exposed methods | slots | custom tooltip | themes |
| --- | --- | --- | --- | --- | --- | --- |
| `VueUiGeo` | `VueUiGeoDatasetItem[]` | `VueUiGeoConfig` | `generatePdf`, `generateImage`, `toggleTooltip`, `toggleAnnotator`, `getImage`, `zoomIn`, `zoomOut`, `resetZoom`, `focusLocation`, `#hint` | `#svg`, `#svg-underlayer`, `#watermark`, `#pattern`, `#chart-background`, `#datapoint` | ✅ | ✅ |
| `VueUiWorld` | `VueUiWorldDataset` | `VueUiWorldConfig` | `getData`, `generatePdf`, `generateImage`, `toggleTable`, `toggleTooltip`, `toggleAnnotator`, `getImage` | `#svg`, `#svg-underlayer`, `#watermark`, `#pattern`, `#chart-background` | ✅ | ✅ |

### Data tables

<!-- prettier-ignore -->
| Name | dataset type | config type | emits / exposed methods | slots | themes |
| --- | --- | --- | --- | --- | --- |
| `VueUiTable` | `VueUiTableDataset` | `VueUiTableConfig` | ❌ | ❌ | ❌ |
| `VueUiTableHeatmap` | `VueUiTableHeatmapDatasetItem[]` | `VueUiTableHeatmapConfig` | `generatePdf`, `generateCsv`, `generateImage` | `#caption`, `#rowTitle`, `#cell`, `#sum`, `#average`, `#median` | ✅ |
| `VueUiTableSparkline` | `VueUiTableSparklineDatasetItem[]` | `VueUiTableSparklineConfig` | `generatePdf`, `generateCsv`, `generateImage` | ❌ | ✅ |
| `VueUiCarouselTable` | `VueUiCarouselTableDataset` | `VueUiCarouselTableConfig` | `generatePdf`, `generateImage`, `generateCsv`, `toggleAnimation`, `pauseAnimation`, `resumeAnimation` | `#caption`, `#th`, `#td` | ❌ |

### Rating

<!-- prettier-ignore -->
| Name | dataset type | config type | emits / exposed methods | slots |
| --- | --- | --- | --- | --- |
| `VueUiRating` | `VueUiRatingDataset` | `VueUiRatingConfig` | `@rate`, `getData`,`toggleReadonly` | `#layer-under`, `#layer-above` |
| `VueUiSmiley` | `VueUiRatingDataset` | `VueUiSmileyConfig` | `@rate`, `getData`,`toggleReadonly` |  |

### Productivity

<!-- prettier-ignore -->
| Name | dataset type | config type | emits / exposed methods | slots | custom tooltip | themes |
| --- | --- | --- | --- | --- | --- | --- |
| `VueUiHill` | `VueUiHillDatasetItem` | `VueUiHillConfig` | `edit`, `save`, `cancel`, `copyAlt`, `dragStart`, `dragEnd`, `datapointEnter`, `datapointLeave`, `selectDatapoint`, `generatePdf`, `generateImage`, `getImage` | `#svg`, `#svg-underlayer`, `#analysis`, `#loading`, `#watermark`, `#chart-background`, `#hill-edit`, `#hill-cancel`, `#hill-save` | ❌ | ✅ |

### Utilities

<!-- prettier-ignore -->
| Name | dataset type | config type | emits / exposed methods | slots |
| --- | --- | --- | --- | --- |
| `VueUiAccordion` | ❌ | `VueUiAccordionConfig` | ❌ | `#arrow`, `#title`, `#content` |
| `VueUiAnnotator` | `VueUiAnnotatorDataset` | `VueUiAnnotatorConfig` | `@toggleOpenState`, `@saveAnnotations` | `#toggle`, `#icon-move`, `#icon-resize`, `#icon-delete`, `#icon-select-group`, `#icon-bring-to-front`, `#icon-bring-to-back`, `#icon-copy`, `#icon-undo`, `#icon-redo`, `#icon-print`, `#icon-export-image`, `#icon-save`, `#icon-circle`, `#icon-rect`, `#icon-arrow`, `#icon-freehand`, `#icon-text`, `#icon-text-align-left`, `#icon-text-align-center`, `#icon-text-align-right`, `#icon-text-bullet-points`, `#icon-text-bold`, `#icon-text-bold`, `#icon-text-italic`, `#icon-text-underline`, `#icon-color` |
| `VueUiCursor` | ❌ | `VueUiCursorConfig` | ❌ | ❌ |
| `VueUiDashboard` | `VueUiDashboardElement[]` | `VueUiDashboardConfig` | `@change` | `#content`, `#top`, `#bottom` |
| `VueUiDigits` | `number` | `VueUiDigitsConfig` | ❌ | ❌ |
| `VueUiKpi` | `number` | `VueUiKpiConfig` | ❌ | `#title`, `#value`, `#comment-before`, `#comment-after` |
| `VueUiLabel` | `VueUiLabelDataset` | `VueUiLabelConfig` | `@dragStart`, `@drag`, `@dragEnd`, `@mouseenter`, `@mouseleave`, `@click`, `@focus`, `@blur`, `reorder` | `#before`, `#after`, `#title`, `#content` |
| `VueUiMiniLoader` | ❌ | `VueUiMiniLoaderConfig` | ❌ | ❌ |
| `VueUiSkeleton` | ❌ | `VueUiSkeletonConfig` | ❌ | ❌ |
| `VueUiTimer` | ❌ | `VueUiTimerConfig` | `@start`, `@pause`, `@reset`, `@restart`, `@lap` | `#time`, `#controls`, `#laps`, `#chart-background` |
| `VueUiIcon` | see below | - | - | `#exp`, `#sub` |

### Icons

Tailor made icons are available through the VueUiIcon component:

```html
<VueUiIcon name="arrowRight" :size="24" stroke="#6376DD" />
```

All names of available icons are available in the vue-data-ui.d.ts file under the `VueUiIconName` type.

`VueUiIcon` props:

<!-- prettier-ignore -->
| Name | type | Default value |
| --- | --- | --- |
| `name` | `VueUiIconName` | `undefined` |
| `size` | `number` | `24` |
| `stroke` | `string` (color) | `'#CCCCCC'` |
| `strokeWidth` | `number` | `1.5` |
| `isSpin` | `boolean` | `false` |
| `spinDuration` | `string` | `'1s'` |

Icons have 2 slots that can be used to display exp or sub icons:

```html
<VueUiIcon name="database">
  <template #exp v-if="isLoading">
    <VueUiIcon name="spinner2" :is-spin="true"/>
  </template>
  <template #sub>
    <VueUiIcon name="person"/>
  </sub>
</VueUiIcon>
```

# User options

User options menu is accessible in the burger menu located on the top right of the charts, and visible by default.
To hide the user options menu, set config.userOptions.show to false:

```js
const config = ref({
  userOptions: {
    show: false
  },
  ...
})
```

The user options menu can be set to appear only when hovering over the component:

```js
const config = ref({
    userOptions: {
        show: true,
        showOnChartHover: true, // Default: false
        keepStateOnChartLeave: true, // Set to false to always close the menu when hovering out of the chart
    },
});
```

Predefined actions in the user options menu depend on the type of chart. Some charts have more or fewer actions available. Action buttons contain predefined icons by default.

To hide a given action, set the userOption.buttons, for example:

```js
const config = ref({
    userOptions: {
        show: true,
        buttons: {
            pdf: false,
            fullscreen: false,
            altCopy: true,
            // all other pertinent actions for the component will be visible by default (list of all actions below)
        },
    },
});
```

You can use slots to override the content of action buttons.
What happens when the button is clicked is taken care of by the component, except for the optionFullscreen slot.

```html
<VueUiDonut :config="config" :dataset="dataset">
    <template #optionPdf> GENERATE PDF </template>

    <!-- This is the only action where scoped content is provided -->
    <template template #optionFullscreen="{ isFullscreen, toggleFullscreen }">
        <div @click="toggleFullscreen(isFullscreen ? 'out' : 'in')">
            TOGGLE FULLSCREEN
        </div>
    </template>
</VueUiDonut>
```

You can pass a callback through the config, for each button, to override the default behavior:

```ts
const config = {
    userOptions: {
        callbacks: {
            pdf: ({ chartElement, imageUri, base64 }) => {
                console.log(chartElement);
            },
            img: ({ chartElement, imageUri, base64 }) => {
                console.log(base64);
            },
            csv: (csvStr: string) => {
                console.log(csvStr);
            },
            altCopy: ({ dataset: dst, config: cfg }) => {
                console.log({ dst, cfg });
            },
            // the other attributes also have the same names as the buttons
        },
    },
};
```

User options actions available per chart:

<!-- prettier-ignore -->
| Chart name | User options actions slot names |
| --- | --- |
| VueUi3dBar | optionAltCopy, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionSvg |
| VueUiAgePyramid | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionSvg |
| VueUiBump | optionAltCopy, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionSvg |
| VueUiBullet | optionAltCopy, optionPdf, optionImg, optionFullscreen, optionAnnotator, optionSvg |
| VueUiCandlestick | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionSvg |
| VueUiCarouselTable | optionAltCopy, optionPdf, optionImg, optionCsv, optionAnimation, optionFullscreen |
| VueUiChestnut | optionAltCopy, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionSvg |
| VueUiChord | optionAltCopy, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionSvg |
| VueUiCirclePack | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionSvg |
| VueUiDag | optionAltCopy, optionPdf, optionImg, optionSvg, optionFullscreen, optionAnnotator, optionZoom |
| VueUiDonut | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionLabels, optionFullscreen, optionAnnotator, optionSvg |
| VueUiDonutEvolution | optionAltCopy, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionSvg |
| VueUiDumbbell | optionAltCopy, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionSvg |
| VueUiFlow | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionSvg |
| VueUiFunnel | optionAltCopy, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionSvg |
| VueUiGalaxy | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionSvg |
| VueUiGauge | optionAltCopy, optionPdf, optionImg, optionFullscreen, optionAnnotator, optionSvg |
| VueUiGraph | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionZoom, optionSvg |
| VueUiGeo | optionAltCopy, optionPdf, optionImg, optionFullscreen, optionAnnotator, optionZoom, optionSvg |
| VueUiHeatmap | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionSvg |
| VueUiHistoryPlot | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionSvg |
| VueUiHorizontalBar | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionSort, optionFullscreen, optionAnnotator, optionSvg |
| VueUiMolecule | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionLabels, optionFullscreen, optionAnnotator, optionZoom, optionSvg |
| VueUiMoodRadar | optionAltCopy, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionSvg |
| VueUiNestedDonuts | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionLabels, optionFullscreen, optionAnnotator, optionSvg |
| VueUiOnion | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionSvg |
| VueUiParallelCoordinatePlot | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionLabels, optionFullscreen, optionAnnotator, optionSvg |
| VueUiQuadrant | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionLabels, optionFullscreen, optionAnnotator, optionSvg |
| VueUiQuickChart | optionAltCopy, optionTooltip, optionPdf, optionImg, optionFullscreen, optionAnnotator, optionSvg |
| VueUiRadar | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionSvg |
| VueUiRelationCircle | optionAltCopy, optionPdf, optionImg, optionFullscreen, optionAnnotator, optionSvg |
| VueUiRidgeline | optionAltCopy, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionSvg |
| VueUiRings | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionLabels, optionSvg |
| VueUiScatter | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionSvg |
| VueUiSparkHistogram | (no user options menu) |
| VueUiSparkStackbar | (no user options menu) |
| VueUiSparkTrend | (no user options menu) |
| VueUiSparkbar | (no user options menu) |
| VueUiSparkgauge | (no user options menu) |
| VueUiSparkline | (no user options menu) |
| VueUiStackbar | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionLabels, optionFullscreen, optionAnnotator, optionSvg |
| VueUiStackline | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionLabels, optionFullscreen, optionAnnotator, optionSvg |
| VueUiStripPlot | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionLabels, optionFullscreen, optionAnnotator, optionSvg |
| VueUiTableHeatmap | optionAltCopy, optionPdf, optionImg, optionCsv, optionFullscreen |
| VueUiTableSparkline | optionAltCopy, optionPdf, optionImg, optionCsv, optionFullscreen |
| VueUiThermometer | optionAltCopy, optionPdf, optionImg, optionFullscreen, optionAnnotator, optionSvg |
| VueUiTiremarks | optionAltCopy, optionPdf, optionImg, optionFullscreen, optionAnnotator, optionSvg |
| VueUiTreemap | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator , optionSvg |
| VueUiWaffle | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator , optionSvg |
| VueUiWheel | optionAltCopy, optionPdf, optionImg, optionFullscreen, optionAnnotator, optionSvg |
| VueUiWordCloud | optionAltCopy, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionZoom, optionSvg |
| VueUiWorld | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionFullscreen, optionAnnotator, optionSvg |
| VueUiXy | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionLabels, optionFullscreen, optionStack, optionAnnotator, optionSvg |
| VueUiXyCanvas | optionAltCopy, optionTooltip, optionPdf, optionImg, optionCsv, optionTable, optionLabels, optionFullscreen, optionStack, optionAnnotator |
| VueUiHill | optionAltCopy, optionPdf, optionImg, optionCsv optionLabels, optionFullscreen, optionAnnotator, hill-edit, hill-cancel, hill-save |

User options menu icon can be customized using the #menuIcon slot:

```html
<template #menuIcon="{ isOpen, color }">
    <div>{{ isOpen ? 'close' : 'open' }}</div>
</template>
```

Since version 3.5.1, slots are exposed to customize the chart annotator sub-menu:

```html
<VueUiXy :dataset="dataset" :config="config">
    <template #annotator-action-close>
        <MyCloseIcon />
    </template>
    <template #annotator-action-color="{ color }">
        <MyColorIcon :color="color" />
    </template>
    <template #annotator-action-draw="{ mode }">
        <MyDrawIcon v-if="mode === 'draw'" />
        <MyTextIcon v-else />
    </template>
    <template #annotator-action-undo="{ disabled }">
        <MyUndoIcon />
    </template>
    <template #annotator-action-redo="{ disabled }">
        <MyRedoIcon />
    </template>
    <template #annotator-action-delete="{ disabled }">
        <MyDeleteIcon />
    </template>
</VueUiXy>
```

# Custom palette

It is possible to provide a custom palette in the config prop through config.customPalette (string[]) for the following components:

- VueUi3dBar
- VueUiBump
- VueUiChestnut
- VueUiChord
- VueUiCirclePack
- VueUiDonut
- VueUiDonutEvolution
- VueUiFlow
- VueUiGalaxy
- VueUiGraph
- VueUiGauge
- VueUiHistoryPlot
- VueUiHorizontalBar
- VueUiMolecule
- VueUiNestedDonuts
- VueUiOnion
- VueUiParallelCoordinatePlot
- VueUiQuadrant
- VueUiQuickChart
- VueUiRadar
- VueUiRelationCircle
- VueUiRidgeline
- VueUiRings
- VueUiScatter
- VueUiSparkStackbar
- VueUiSparkbar
- VueUiStackbar
- VueUiStackline
- VueUiStripPlot
- VueUiTableSparkline
- VueUiThermometer
- VueUiTreemap
- VueUiWaffle
- VueUiWordCloud
- VueUiWorld
- VueUiXy
- VueUiXyCanvas

If the array of colors provided in customPalette is too small for the dataset, remaining colors will be computed from the default internal palette.
Accepted color formats: HEX, RGB, HSL, named colors.

# Responsive charts

By default, all charts will scale to the width of their container.
However the following charts can be made fully responsive, making them better to use in resizable containers:

<!-- prettier-ignore -->
| Component | Responsive feature implemented |
| --- | --- |
| VueUi3dBar | ✅ |
| VueUiAgePyramid | ✅ |
| VueUiAgePyramid | ✅ |
| VueUiBullet | ✅ |
| VueUiBump | ✅ |
| VueUiCarouselTable | - |
| VueUiChestnut | - |
| VueUiChord | ✅ |
| VueUiCirclePack | ✅ |
| VueUiDag | ✅ |
| VueUiDonut | ✅ |
| VueUiDonutEvolution | ✅ |
| VueUiDumbbell | ✅ |
| VueUiFlow | ✅ |
| VueUiFunnel | ✅ |
| VueUiGalaxy | ✅ |
| VueUiGauge | ✅ |
| VueUiGeo | ✅ |
| VueUiGraph | ✅ |
| VueUiHeatmap | ✅ |
| VueUiHistoryPlot | ✅ |
| VueUiHorizontalBar | ✅ |
| VueUiMolecule | - |
| VueUiMoodRadar | ✅ |
| VueUiNestedDonuts | ✅ |
| VueUiOnion | ✅ |
| VueUiParallelCoordinatePlot | ✅ |
| VueUiQuadrant | ✅ |
| VueUiQuickChart | ✅ |
| VueUiRadar | ✅ |
| VueUiRelationCircle | ✅ |
| VueUiRidgeline | ✅ |
| VueUiRings | ✅ |
| VueUiScatter | ✅ |
| VueUiSparkHistogram | ✅ |
| VueUiSparkStackbar | - |
| VueUiSparkTrend | ✅ |
| VueUiSparkbar | - |
| VueUiSparkgauge | - |
| VueUiSparkline | ✅ |
| VueUiStackbar | ✅ |
| VueUiStackline | ✅ |
| VueUiStripPlot | ✅ |
| VueUiTableHeatmap | - |
| VueUiTableSparkline | - |
| VueUiThermometer | ✅ |
| VueUiTimer | ✅ |
| VueUiTiremarks | ✅ |
| VueUiTreemap | ✅ |
| VueUiWaffle | ✅ |
| VueUiWheel | ✅ |
| VueUiWordCloud | ✅ |
| VueUiWorld | - |
| VueUiXy | ✅ |
| VueUiXyCanvas | ✅ |

To activate responsiveness, set the config.responsive attribute to true:

```js
const config = ref({
    responsive: true,
    // rest of your config
});
```

**Important:** when using the responsive feature, charts must be placed inside a container with fixed dimensions. Avoid setting a 100% height to this container, as it will result in the chart growing infinitely.

# Big data optimization (since v2.4.11)

Very large datasets (> 5k or > 10k datapoints) will cause the browsers rendering engines to slow down, caused by too many SVG DOM elements to render.
The following charts use the LTTB algorithm (Largest-Triangle-Three-Bucket) beyond a certain threshold to downsample the rendered dataset while preserving its shape. These components are the most susceptible to be used with very large datasets:

<!-- prettier-ignore -->
| Component | Default Threshold | Remark |
| --- | --- | --- |
| VueUiXy | 1095 |  |
| VueUiXyCanvas | 10000 | Since this chart uses canvas, the threshold can be set higher |
| VueUiQuadrant | 1095 |  |
| VueUiScatter | 1095 |  |
| VueUiSparkline | 1095 |  |
| VueUiSparkTrend | 1095 |  |

The downsample threshold for each component can be set in the config prop passed to components:

```js
const config = ref({
  downsample: {
    threshold: 500,
  },
  ...// rest of your config
})
```

# Chart custom background (since v2.4.59)

A #chart-background slot is available on most charts to customize their background, to display a gradient, an image, etc.
The content placed inside this slot has pointer-events set to none, so it does not interfere with the components' interactivity.

```html
<VueUiXy :config="config" :dataset="dataset">
    <template #chart-background>
        <div
            style="width: 100%; height: 100%; background: radial-gradient(at top left, red, white)"
        />
    </template>
</VueUiXy>
```

The following components do not support this slot, because it would not make sense:

- VueUiCarouselTable
- VueUiDag
- VueUiGizmo
- VueUiIcon
- VueUiKpi
- VueUiRating
- VueUiSmiley
- VueUiSparkStackbar
- VueUiSparkbar
- VueUiTableHeatmap
- VueUiTableSparkline
- VueUiTreemap
- VueUiWaffle
- VueUiXyCanvas

# Pattern slot (v2.4.67+)

A #pattern slot is available on some components to apply custom patterns on datapoints for further customization.
The slot exposes the seriesIndex, and a patternId which must be used on the pattern element to be recognized.
A pattern element must be used inside this slot. It will be injected inside a defs element of the component.

```html
<VueUiDonut :config="config" :dataset="dataset">
    <template #pattern="{ seriesIndex, patternId }">
        <!-- Apply a pattern on the first datapoint only -->
        <pattern
            v-if="seriesIndex === 0"
            :id="patternId"
            viewBox="0,0,10,10"
            width="10%"
            height="10%"
        >
            <polygon points="0,0 2,5 0,10 5,8 10,10 8,5 10,0 5,2" />
        </pattern>
    </template>
</VueUiDonut>
```

The #pattern slot is available on the following components:

- VueUiChord
- VueUiCirclePack
- VueUiDonut
- VueUiGauge
- VueUiRidgeline
- VueUiRings
- VueUiStackbar
- VueUiStackline
- VueUiHorizontalBar
- VueUiWaffle
- VueUiWorld
- VueUiXy

A set of 12 readymade patterns is available through the VueUiPattern component:

```js
import { VueUiPattern } from 'vue-data-ui';
```

```html
<VueUiDonut :dataset="dataset" :config="config">
    <template #pattern="{ seriesIndex, patternId }">
        <VueUiPattern :id="patternId" name="bubbles" v-if="seriesIndex === 0" />
        <VueUiPattern :id="patternId" name="squares" v-if="seriesIndex === 1" />
    </template>
</VueUiDonut>
```

VueUiPattern accepts the following props:

- id: string, required. Pass the patternId provided by the #pattern slot
- name: string, required. The name of the pattern to use
- fill: string, optional. The backgroundColor of the pattern. Transparent by default to show the datapoint base color
- stroke: string, optional. Default: #2D353C
- strokeWidth: number, optional. Default: 1
- scale: number, optional. Default: 1

List of available patterns:

<!-- prettier-ignore -->
| pattern name |
| --- |
| bubbles |
| flooring |
| grid |
| hexagon-diamond |
| hexagon-flooring |
| hexagon-grid |
| maze |
| redrum |
| scales |
| squares |
| wave |
| zigzag |

# Utility functions

A set of utility functions is available:

```js
import {
    abbreviate,
    darkenColor,
    lightenColor,
    shiftColorHue,
    createTSpans,
    getCumulativeAverage,
    getCumulativeMedian,
} from 'vue-data-ui';
```

### abreviate

```js
import { abbreviate } from 'vue-data-ui';

const text = 'lorem ipsum dolor sit amet';
const abbreviated = abbreviate({
    source: text,
    length: 5,
}); // Result: LIDSA
```

### darkenColor

```js
import { darkenColor } from 'vue-data-ui';

const color = '#FF0000';
const darkened = darkenColor(color, 0.5); // Result: #800000ff
```

### lightenColor

```js
import { lightenColor } from 'vue-data-ui';

const color = '#FF0000';
const lightened = lightenColor(color, 0.5); // Result: #ff8080ff
```

### shiftColorHue

```js
import { shiftColorHue } from 'vue-data-ui';

// Color format can be HEX (with or without alpha channel), RGB, RGBA, or named color
const color = '#FF0000';
const shifted = shiftColorHue(color, 0.1); // Result: #ff9900ff
```

### createTSpans

```js
import { createTSpans } from 'vue-data-ui';

const textContent = createTSpans({
    content: 'This is an example of multiline text',
    fontSize: 16,
    fill: '#1A1A1A',
    maxWords: 3,
    x: 10,
    y: 20,
});
```

```html
<!-- The output must be used inside a svg text element with `v-html`, for example in a #data-label slot, or in your own svg -->

<text
    :x="10"
    :y="20"
    fill="#1A1A1A"
    :font-size="16"
    text-anchor="middle"
    v-html="textContent"
/>
```

### getCumulativeAverage

```js
import { getCumulativeAverage } from 'vue-data-ui';

// simple usage
const arr = [0, 1, 2, 3, 4];
const cumulativeAvg = getCumulativeAverage({ values: arr });

// Ignore invalid values entirely
const arrWithInvalid = [1, null, 2, Infinity, NaN, undefined];
const cumulativeAvgNoInvalid = getCumulativeAverage({
    values: arrWithInvalid,
    config: {
        keepInvalid: false,
    },
});

// Convert invalid values to zero
const cumulativeAvgZeroed = getCumulativeAverage({
    values: arrWithInvalid,
    config: {
        convertInvalidToZero: true,
    },
});
```

### getCumulativeMedian

```js
import { getCumulativeMedian } from 'vue-data-ui';

// simple usage
const arr = [0, 1, 2, 3, 4];
const cumulativeMed = getCumulativeMedian({ values: arr });

// Ignore invalid values entirely
const arrWithInvalid = [1, null, 2, Infinity, NaN, undefined];
const cumulativeMedNoInvalid = getCumulativeMedian({
    values: arrWithInvalid,
    config: {
        keepInvalid: false,
    },
});

// Convert invalid values to zero
const cumulativeMedZeroed = getCumulativeMedian({
    values: arrWithInvalid,
    config: {
        convertInvalidToZero: true,
    },
});
```

### mergeConfigs

```js
import { mergeConfigs, getVueDataUiConfig } from 'vue-data-ui';
const defaultConfig = getVueDataUiConfig('vue_ui_xy');

// Create a full config with user overrides
const merged = mergeConfigs({
    defaultConfig,
    userConfig: {
        chart: {
            backgroundColor: '#FF0000',
        },
    },
});
```

## Multiline data labels

Some components will display labels on multiple lines when the provided text contains a line break. (example: "I contain a\nline break").
Below is a table of the places where such line breaks can be used:

<!-- prettier-ignore -->
| Component | Label displayed | Where to use line breaks |
| --- | --- | --- |
| VueUiBump | Series labels | dataset names |
| VueUiDag | Node labels | dataset label |
| VueUiGraph | Node labels | dataset.nodes[].label |
| VueUiDonutEvolution | Time labels (x axis) | config.style.chart.layout.grid.xAxis.dataLabels.values |
| VueUiHistoryPlot | Plot labels | dataset names |
| VueUiHorizontalBar | Series labels | dataset names |
| VueUiParallelCoordinatePlot | Axis labels | config.style.chart.yAxis.labels.axisNames |
| VueUiQuadrant | Plot labels | dataset names |
| VueUiQuickChart | Time labels (x axis) | config.xyPeriods |
| VueUiRidgeline | Time labels (x axis) | config.style.chart.xAxis.labels.values |
| VueUiRings | Series labels | dataset names |
| VueUiStackbar | Time labels (x axis) | config.style.chart.grid.x.timeLabels.values |
| VueUiStackline | Time labels (x axis) | config.style.chart.grid.x.timeLabels.values |
| VueUiStripPlot | x axis labels | dataset names |
| VueUiXy | Time labels (x axis) | config.chart.grid.labels.xAxisLabels.values |

## PDF generation

This package requires jspdf as a peer dependency. Please install it in your project if you intend to use the PDF printing feature.

## `useObjectBindings`

A composable that **flattens** a reactive object into a set of refs (one for each “leaf” property) so you can easily bind to deeply nested values by their string paths.

### Why use it?

- **Automatic reactivity**: Every nested property becomes a `Ref`, with automatic getters/setters that keep your source object in sync.
- **Flat API surface**: Access or update any nested field by its dot‑delimited path, without writing deep destructuring or `ref` plumbing.
- **Dynamic path support**: New paths added at runtime are discovered automatically (and proxied), so you never lose reactivity when mutating the structure.

```js
import { useObjectBindings, getVueDataUiConfig } from 'vue-data-ui';

const config = ref(getVueDataUiConfig('vue_ui_donut')); // or your custom config for this component

const bindings = useObjectBindings(config);
// Now `bindings` has computed refs for each leaf path:
//   bindings["style.chart.backgroundColor"] → Ref<string>
//   bindings["style.chart.color"] → Ref<string>
//   bindings["customPalette"] → Ref<boolean>
//   by default, arrays are skipped:
//   no "customPalette.0", unless you disable skipArrays
```

You can then use these in your template:

```html
<template>
    <div>
        <input
            type="color"
            v-model="bindings['style.chart.backgroundColor'].value"
        />
    </div>
</template>
```

## Exposed methods

Most chart components expose the following methods:

### getData

```js
const componentRef = ref(null);

onMounted(async () => {
    if (componentRef) {
        const data = await componentRef.value.getData();
        console.log(data);
    }
});
```

### getImage

```js
const componentRef = ref(null);

onMounted(async () => {
    if (componentRef) {
        const { imgUri, base64, title, width, height, aspectRatio } =
            await componentRef.value.getImage({ scale: 2 }); // optional scale, defaults to 2, increase for better image quality
        console.log(imageUri);
    }
});
```

### showSeries / hideSeries

```ts
showSeries: (name: string) => void
hideSeries: (name: string) => void
```

Set a ref on your chart component to call exposed methods:

```html
<VueUiXy ref="chart" :dataset="dataset" :config="config" />
```

Example:

```js
const chart = ref(null); // Add this ref on the chart component

function showSeriesByName(name) {
    if (!chart.value) return;
    chart.value.showSeries(name);
}

function hideSeriesByName(name) {
    if (!chart.value) return;
    chart.value.hideSeries(name);
}
```

`showSeries` and `hideSeries` exposed methods are available on the following components:

- VueUiDonut
- VueUiDonutEvolution
- VueUiGalaxy
- VueUiHistoryPlot
- VueUiHorizontalBar
- VueUiNestedDonuts
- VueUiOnion
- VueUiParallelCoordinatePlot
- VueUiQuadrant
- VueUiRadar
- VueUiRidgeline
- VueUiRings
- VueUiScatter
- VueUiSparkStackbar
- VueUiStackbar
- VueUiStackline
- VueUiTreemap
- VueUiWaffle
- VueUiXy
- VueUiXyCanvas

## a11y

### Keyboard navigation

Chart components, when applicable, enable keyboard navigation inside the chart area (arrows), to cycle through datapoints when the chart area is in focus.

It is possible to configure the following translations, used in hidden hints for screenreaders:

```js
const config = computed(() => ({
    a11y: {
        translations: {
            keyboardNavigation:
                'Use the left and right arrow keys to move between data points.',
            tableAvailable: 'A data table for this chart is available below.',
            tableCaption: 'Chart data table',
        },
    },
}));
```

A #hint scoped slot is available to display a navigation hint when the chart area is in focus. This slot exposes the `a11y.translations.keyboardNavigation` text, and a `isVisible` boolean which is `true` when the chart area is in focus. The hint is absolutely positioned below the chart area.

```html
<VueUiXy :dataset :config>
    <template #hint="{ hint, isVisible }">
        <!-- Slot content is absolutely positoned below the chart area, but you can style it to adjust the position. -->
        <p v-if="isVisible">{{ hint }}</p>
    </template>
</VueUiXy>
```

The #hint slot is available for the following components:

- VueUiAgePyramid
- VueUiBump
- VueUiCandlestick
- VueUiChord
- VueUiCirclePack
- VueUiDag
- VueUiDonutEvolution
- VueUiDonut
- VueUiDumbbell
- VueUiFlow
- VueUiGalaxy
- VueUiGraph
- VueUiGeo
- VueUiHeatmap
- VueUiHistoryPlot
- VueUiHorizontalBar
- VueUiMoodRadar
- VueUiNestedDonuts
- VueUiOnion
- VueUiParallelCoordinatePlot
- VueUiQuadrant
- VueUiQuickChart
- VueUiRadar
- VueUiRelationCircle
- VueUiRidgeline
- VueUiRings
- VueUiScatter
- VueUiSparkHistogram
- VueUiSparkline
- VueUiSparkStackbar
- VueUiStackbar
- VueUiStackline
- VueUiStripPlot
- VueUiTreemap
- VueUiWaffle
- VueUiWordCloud
- VueUiXy
- VueUiXyCanvas

### Copy alt text

On all charts with a contextual menu, the `altCopy` button can be enabled.
The purpose of this button is to provide the necessary data to create a custom alt text, that can be copied when posting a picture of the chart on socials for example.

```js
const config = computed(() => (
  userOptions: {
    buttons: {
      altCopy: true, // false by default. Set to true to display the button in the context menu
    },
    callbacks: {
      altCopy: ({ dataset:dst, config:cfg }) => {
        // Convert the data into a tailor-made alt text you can copy to the clipboard
      }
    },
    buttonTitles: {
      altCopy: 'Copy alt text' // provide your translation for the button's tooltip
    }
  }
));
```

A slot is available to customize the contents of the button:

```html
<VueUiXy :dataset="dataset" :config="config">
    <template #optionAltCopy>
        <MyAccessibilityIcon />
    </template>
</VueUiXy>
```

### opt-in cursor pointer

Starting from v3.15.0, all clickable elements will have a default cursor.
To have a cursor pointer on these elements, you have to opt-in through the config:

```js
const config = computed(() => ({
    useCursorPointer: true, // false by default
}));
```
